import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Phone, Clock, Menu, X, AlertTriangle, Search } from "lucide-react";
import logo from "../assets/logo.webp";
import { SiteSearch } from "./SiteSearch";

export function Header({ cms }: { cms?: any }) {
  const socials = cms?.socials || {};
  const phone = socials.phone || "+917507408461";
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  const closeMobileMenu = () => setIsMobileMenuOpen(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-background/60 border-b border-border">
      <div className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between">
        <Link to="/" hash="top" className="flex items-center gap-2.5" onClick={closeMobileMenu}>
          <img src={logo} alt="Prime Cool logo" className="h-9 w-9" />
          <span className="font-display font-bold text-lg tracking-tight">
            Prime <span className="text-gradient">Cool</span>
          </span>
        </Link>
        <nav className="hidden md:flex items-center gap-6 text-sm text-muted-foreground">
          <Link
            to="/industrial/chiller-plant-operations"
            className="hover:text-foreground transition font-semibold"
          >
            Industrial Systems
          </Link>
          <Link to="/" hash="services" className="hover:text-foreground transition">
            Services
          </Link>
          <Link to="/portfolio" className="hover:text-foreground transition">
            Case Studies
          </Link>
          <Link to="/resources" className="hover:text-foreground transition">
            Resources
          </Link>
          <Link to="/blogs" className="hover:text-foreground transition">
            Blogs
          </Link>
          <Link to="/" hash="about" className="hover:text-foreground transition">
            About
          </Link>
          <Link
            to="/emergency"
            className="hover:text-red-500 transition text-red-500 font-bold flex items-center gap-1"
          >
            <AlertTriangle className="h-3.5 w-3.5" /> Code Red
          </Link>
        </nav>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsSearchOpen(true)}
            className="p-2 text-foreground hover:bg-muted rounded-full transition"
            aria-label="Search"
          >
            <Search className="h-5 w-5" />
          </button>
          <a
            href={`tel:${phone.replace(/\\s+/g, "")}`}
            className="hidden sm:inline-flex items-center gap-2 rounded-full border border-border p-2 sm:px-3 sm:py-1.5 text-xs font-medium hover:bg-card transition"
            title="Call Support"
          >
            <Phone className="h-4 w-4 text-primary" />
            <span className="hidden sm:inline">{phone}</span>
          </a>
          <Link
            to="/booking"
            search={{}}
            className="hidden sm:inline-flex items-center gap-2 rounded-full bg-primary text-primary-foreground px-4 py-2 text-sm font-medium hover:opacity-90 transition glow-ring"
            onClick={closeMobileMenu}
          >
            <Clock className="h-4 w-4" />
            <span>Book Online</span>
          </Link>
          <button
            className="md:hidden p-2 text-foreground"
            onClick={toggleMobileMenu}
            aria-label="Toggle mobile menu"
          >
            {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-16 left-0 right-0 bg-background/95 backdrop-blur-xl border-b border-border shadow-2xl p-6 flex flex-col gap-6 h-[calc(100vh-64px)] overflow-y-auto">
          <nav className="flex flex-col gap-4 text-lg font-medium text-foreground">
            <Link
              to="/industrial/chiller-plant-operations"
              onClick={closeMobileMenu}
              className="hover:text-primary transition font-semibold"
            >
              Industrial Systems
            </Link>
            <Link
              to="/"
              hash="services"
              onClick={closeMobileMenu}
              className="hover:text-primary transition"
            >
              Services
            </Link>
            <Link
              to="/portfolio"
              onClick={closeMobileMenu}
              className="hover:text-primary transition"
            >
              Case Studies
            </Link>
            <Link
              to="/resources"
              onClick={closeMobileMenu}
              className="hover:text-primary transition"
            >
              Resources Hub
            </Link>
            <Link
              to="/blogs"
              onClick={closeMobileMenu}
              className="hover:text-primary transition"
            >
              Blogs
            </Link>
            <Link
              to="/"
              hash="about"
              onClick={closeMobileMenu}
              className="hover:text-primary transition"
            >
              About
            </Link>
            <Link
              to="/emergency"
              onClick={closeMobileMenu}
              className="text-red-500 font-bold transition flex items-center gap-2"
            >
              <AlertTriangle className="h-4 w-4" /> Code Red Dispatch
            </Link>
          </nav>
          <div className="mt-auto pt-6 border-t border-border/40 flex flex-col gap-4">
            <a
              href={`tel:${phone.replace(/\\s+/g, "")}`}
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-border p-4 text-sm font-semibold hover:bg-card transition"
            >
              <Phone className="h-5 w-5 text-primary" />
              <span>Call Now: {phone}</span>
            </a>
            <Link
              to="/booking"
              search={{}}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary text-primary-foreground p-4 text-sm font-semibold hover:opacity-90 transition glow-ring"
              onClick={closeMobileMenu}
            >
              <Clock className="h-5 w-5" />
              <span>Book Online Service</span>
            </Link>
          </div>
        </div>
      )}
      <SiteSearch isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
    </header>
  );
}
